# Posts
This folder contains all social media posts that will be uploaded to Watson Discovery.
